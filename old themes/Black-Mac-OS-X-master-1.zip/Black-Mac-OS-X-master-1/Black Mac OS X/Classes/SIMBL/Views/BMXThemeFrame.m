//
//  BMXThemeFrame.m
//  Black Mac OS X
//
//  Created by Alex Zielenski on 2/5/11.
//  Copyright 2011 Alex Zielenski. All rights reserved.
//
#import "BMXThemeFrame.h"


@interface NSThemeFrame (QuietWarnings)

- (void)orig_drawFrame:(CGRect)fp8;
- (id)orig_customTitleCell;
- (void)orig_drawTitleBar:(CGRect)fp8;
- (void)orig_dealloc;
@end

@implementation NSThemeFrame (BMXThemeFrame)
#pragma mark - Init
+ (void)swizzle {
	NSError *err = nil;
	[NSThemeFrame jr_aliasMethod:@selector(_drawTitleBar:) 
					withSelector:@selector(orig_drawTitleBar:) 
						   error:&err];
	//NSLog(@"%@", err);
	[NSThemeFrame jr_swizzleMethod:@selector(_drawTitleBar:)
						withMethod:@selector(new_drawTitleBar:)
							 error:&err];
	//NSLog(@"%@", err);
	[NSThemeFrame jr_aliasMethod:@selector(drawFrame:) 
					withSelector:@selector(orig_drawFrame:)
						   error:&err];
	//NSLog(@"%@", err);
	[NSThemeFrame jr_swizzleMethod:@selector(drawFrame:)
						withMethod:@selector(new_drawFrame:)
							 error:&err];
	//NSLog(@"%@", err);
	[NSThemeFrame jr_aliasMethod:@selector(_customTitleCell) 
					withSelector:@selector(orig_customTitleCell) 
						   error:&err];
	//NSLog(@"%@", err);
	[NSThemeFrame jr_swizzleMethod:@selector(_customTitleCell)
						withMethod:@selector(new_customTitleCell)
							 error:&err];
	//NSLog(@"%@", err);
	[NSThemeFrame jr_aliasMethod:@selector(dealloc) 
					withSelector:@selector(orig_dealloc)
						   error:&err];
	//NSLog(@"%@", err);
	[NSThemeFrame jr_swizzleMethod:@selector(dealloc)
						withMethod:@selector(new_dealloc)
							 error:&err];
	
	//NSLog(@"%@", err);
}
- (BOOL)isBMXCustomized {
	Method origMethod = class_getInstanceMethod([self class], @selector(new_drawTitleBar:));
	if (!origMethod)
		return NO;
	//NSLog(@"customized");
	return YES;
}

#pragma mark - Drawing
- (void)new_drawTitleBar:(struct CGRect)arg1 {	// IMP=0x001023e0	
	if ((self.styleMask & NSTitledWindowMask)!=NSTitledWindowMask) {
		[self orig_drawTitleBar:arg1];
		return;
	}
	[self drawTitleBar];
}
- (void)new_drawFrame:(struct CGRect)arg1 {	
	if ((self.styleMask & NSTitledWindowMask)!=NSTitledWindowMask) {
		[self orig_drawFrame:arg1];
		return;
	}
	
	// If it isn't textured , draw the titlebar;
	
	[self drawTitleBar];
	[self _drawTitleStringIn:self.bounds withColor:[NSColor whiteColor]];

}


#pragma mark - Title
- (id)new_customTitleCell {
	id cell = [self orig_customTitleCell];
	if ((self.styleMask & NSTitledWindowMask)!=NSTitledWindowMask)
		return cell;
	if (cell)
		[(NSTextFieldCell*)cell setBackgroundStyle:NSBackgroundStyleLowered];
	return cell;
}

- (void)drawTitleBar {
	if ((self.styleMask & NSTitledWindowMask)!=NSTitledWindowMask)
		return;
	
	BOOL utilityWindow = ((self.styleMask&NSUtilityWindowMask)==NSUtilityWindowMask);
	
	CGFloat topBarHeight = self._topBarHeight;
	
	// Create a top titlebar rectangle to fill. If it has a toolbar, add the toolbar's actual hight
    NSRect frame = [self frame];
    NSRect titleRect = NSMakeRect(0, NSMaxY(frame) - topBarHeight, NSWidth(frame), topBarHeight);
	

	

	

	NSRectFill(NSMakeRect(NSMinX(titleRect), NSMinY(titleRect), NSWidth(titleRect), 1));
}


- (void)_windowChangedKeyState {
	[self.window display];
}

#pragma mark - Other
- (void)new_dealloc {

	
	[self orig_dealloc]; // equivalent to calling [super dealloc]?
}
@end
