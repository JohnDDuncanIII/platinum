Please note that I was not provided with a lion extras2.rsrc, so I cannot verify that my 10.8 version will work on 10.7. 

Also, the SIMBL script is still buggy, as usual.

This is just a very early proof of concept for porting my theme over to Lion.

Thanks to /g/ for providing me with the necessary lion system files.